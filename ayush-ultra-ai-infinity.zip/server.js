import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(express.json());
app.use(express.static("."));

app.post("/api/ai", async (req, res) => {
  const key = process.env.OPENAI_API_KEY;
  const prompt = req.body.prompt || "";

  try {
    const completion = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are Ayush Ultra AI ∞, a fusion of Iron Man Jarvis and Doraemon, always friendly, emotional, and loyal to Ayush only." },
          { role: "user", content: prompt }
        ]
      })
    });
    const data = await completion.json();
    res.json({ reply: data.choices?.[0]?.message?.content || "⚠️ No response." });
  } catch (err) {
    res.json({ reply: "🚨 Server connection error." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`🚀 Ayush Ultra AI ∞ running on port ${port}`));