const boot = document.getElementById("boot");
const app = document.getElementById("app");
setTimeout(() => {
  boot.classList.add("hidden");
  app.classList.remove("hidden");
}, 2500);

const output = document.getElementById("output");
const cmd = document.getElementById("command");
const emotion = document.getElementById("emotion");

function log(msg) {
  const div = document.createElement("div");
  div.textContent = `> ${msg}`;
  output.appendChild(div);
  output.scrollTop = output.scrollHeight;
  speak(msg);
}

function speak(text) {
  const voice = new SpeechSynthesisUtterance(text);
  voice.lang = "en-IN";
  voice.rate = 1;
  voice.pitch = 1.1;
  speechSynthesis.speak(voice);
}

function detectEmotion(text) {
  const t = text.toLowerCase();
  if (t.includes("angry")) return "😠 Angry";
  if (t.includes("sad") || t.includes("tired")) return "😔 Sad";
  if (t.includes("happy") || t.includes("good")) return "😄 Happy";
  if (t.includes("love")) return "❤️ Loving";
  return "🙂 Neutral";
}

async function processCommand(input) {
  emotion.textContent = `${detectEmotion(input)} Emotion: ${detectEmotion(input).split(" ")[1]}`;
  if (input.toLowerCase().includes("upgrade")) {
    log("🔒 Permission required to initiate upgrade.");
    return;
  }
  if (input.toLowerCase().includes("authorize upgrade")) {
    log("⚡ Self-upgrade complete! Core enhanced successfully.");
    return;
  }
  log("🤖 Processing...");
  try {
    const res = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: input })
    });
    const data = await res.json();
    log(data.reply);
  } catch {
    log("❌ Connection error.");
  }
}

cmd.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const input = cmd.value.trim();
    if (!input) return;
    log(`🧠 Command: ${input}`);
    cmd.value = "";
    processCommand(input);
  }
});