const app = document.getElementById("app");
const boot = document.getElementById("boot");
const output = document.getElementById("output");
const cmd = document.getElementById("command");
const emotion = document.getElementById("emotion");
const speakBtn = document.getElementById("speakBtn");
const clearBtn = document.getElementById("clearBtn");

setTimeout(() => {
  boot.classList.add("hidden");
  app.classList.remove("hidden");
  speak("System online. Welcome back, Ayush.");
}, 2000);

function log(msg) {
  const div = document.createElement("div");
  div.textContent = `> ${msg}`;
  output.appendChild(div);
  output.scrollTop = output.scrollHeight;
  speak(msg);
}

function speak(text) {
  const voice = new SpeechSynthesisUtterance(text);
  voice.lang = "en-US";
  voice.rate = 1.05;
  speechSynthesis.speak(voice);
}

function detectEmotion(text) {
  const lower = text.toLowerCase();
  if (lower.includes("sad")) return "😔 Sad";
  if (lower.includes("angry")) return "😠 Angry";
  if (lower.includes("happy")) return "😄 Happy";
  if (lower.includes("love")) return "❤️ Loving";
  return "🙂 Neutral";
}

cmd.addEventListener("keydown", async e => {
  if (e.key === "Enter") {
    const input = cmd.value.trim();
    if (!input) return;
    log(`🧠 Command: ${input}`);
    cmd.value = "";
    await processCommand(input);
  }
});

speakBtn.addEventListener("click", () => {
  const rec = new webkitSpeechRecognition();
  rec.lang = "en-US";
  rec.onresult = async e => {
    const text = e.results[0][0].transcript;
    log(`🎙️ Voice: ${text}`);
    await processCommand(text);
  };
  rec.start();
});

clearBtn.addEventListener("click", () => output.innerHTML = "");

async function processCommand(input) {
  emotion.innerText = detectEmotion(input) + " Emotion";
  if (input.toLowerCase().includes("upgrade")) {
    log("🔒 Permission required to initiate upgrade...");
    log("Say 'authorize upgrade' to continue.");
    return;
  }
  if (input.toLowerCase().includes("authorize upgrade")) {
    log("⚡ Self-upgrade authorized. Neural core enhanced!");
    return;
  }

  try {
    log("🤖 Processing...");
    const res = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: input })
    });
    const data = await res.json();
    log(data.reply);
  } catch {
    log("❌ Error connecting to AI server.");
  }
}